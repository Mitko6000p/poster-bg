import classes from './CreateNickname.module.css';
import { auth } from '../../firebase-config';
import { signOut, updateProfile } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { child, get, getDatabase, onValue, ref, set } from 'firebase/database';
import { useEffect, useRef, useState } from 'react';

export default function CreateNickname() {
  const navigate = useNavigate();
  const nicknameInput = useRef();
  const [validationError, setValidationError] = useState(null);

  useEffect(() => {
    if (auth.currentUser) {
      if (auth.currentUser.displayName) {
        goHome();
      }
    }
  }, []);

  function goHome() {
    navigate('/');
  }

  function createNickname() {
    const dbRef = ref(getDatabase());
    get(child(dbRef, '/users' + auth.currentUser.displayName)).then((snapshot) => {
      if (snapshot.exists()) {
        setValidationError('This nickname is already taken!');
      } else {
        const db = getDatabase();
        set(ref(db, '/users' + '/@' + nicknameInput.current.value), {
          email: auth.currentUser.email,
          followers: 0,
        });
        updateProfile(auth.currentUser, {
          displayName: '@' + nicknameInput.current.value,
        });
        goHome();
      }
    });
  }

  return (
    <menu className={classes.formContainer}>
      <h2 className={classes.title}>Create nickname!</h2>
      <div className={classes.inputContainer}>
        <label>Nickname</label>
        <input type="text" ref={nicknameInput} />
        {validationError && <p>{validationError}</p>}
      </div>
      <button onClick={createNickname} className="btn1" style={{ position: 'absolute', bottom: '15px', right: '15px' }}>
        Create
      </button>
    </menu>
  );
}
