import classes from './Header.module.css';

import HomeIcon from '../../assets/house-icon.png';
import SearchIcon from '../../assets/search-icon.png';

import { Link } from 'react-router-dom';

import { auth } from '../../firebase-config';
import { useEffect, useState } from 'react';
import { signOut } from 'firebase/auth';

export default function Header() {
  const [userData, setUserData] = useState(auth.currentUser);
  const [nicknameHovered, setNicknameHovered] = useState(false);

  useEffect(() => {
    const currentAuth = auth.onAuthStateChanged((user) => {
      setUserData(user);
      setNicknameHovered(false);
    });
  }, [auth]);
  return (
    <header className={classes.appHeader}>
      <Link>
        <button className={classes.logo}>POSTER.BG</button>
      </Link>
      <div className={classes.iconBar}>
        <Link to="/">
          <img src={HomeIcon} alt="Home" />
        </Link>
        <img src={SearchIcon} alt="Search" />
      </div>
      <div className={classes.userInfo}>
        {userData ? (
          <div
            className={classes.userDropdown}
            onMouseEnter={() => setNicknameHovered(true)}
            onMouseLeave={() => setNicknameHovered(false)}
          >
            <h3>{userData.displayName}</h3>
            {nicknameHovered && (
              <menu>
                <section
                  onClick={() => {
                    signOut(auth);
                  }}
                >
                  Sign out
                </section>
              </menu>
            )}
          </div>
        ) : (
          <>
            <Link to="/auth/login">
              <button className="btn1">LogIn</button>
            </Link>
            <Link to="/auth/register">
              <button className="btn1">Register</button>
            </Link>
          </>
        )}
      </div>
    </header>
  );
}
