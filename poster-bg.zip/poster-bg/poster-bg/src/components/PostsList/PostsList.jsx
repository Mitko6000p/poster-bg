import classes from './PostsList.module.css';
import CreatePost from './CreatePost';

export default function PostsList() {
  return (
    <main className={classes.globalContainer}>
      <CreatePost />
    </main>
  );
}
