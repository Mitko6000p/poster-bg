import classes from './PostsList.module.css';

export default function CreatePost() {
  return <div className={classes.postContainer}></div>;
}
