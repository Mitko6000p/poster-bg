import { useParams } from "react-router-dom";
import AuthRegister from "../AuthMethods/AuthRegister.jsx";
import classes from "./Auth.module.css";
import AuthLogin from "../AuthMethods/AuthLogin.jsx";
import CreateNickname from "../CreateNickname/CreateNickname.jsx";

export default function Auth() {
  const { method } = useParams();
  return (
    <main className={classes.globalContainer}>
      {method === "register" && <AuthRegister />}
      {method === "login" && <AuthLogin />}
      {method === "createNickname" && <CreateNickname />}
    </main>
  );
}
