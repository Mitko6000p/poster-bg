import classes from './AuthRegister.module.css';

import GoogleLogo from '../../assets/google-icon.png';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../firebase-config.js';

import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AuthRegister() {
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [confPasswordInput, setConfPasswordInput] = useState('');

  const navigate = useNavigate();

  useEffect(() => {
    if (auth.currentUser) {
      navigate('/');
    }
  }, []);

  const [validationError, setValidationError] = useState({
    email: null,
    password: null,
    confPassword: null,
  });

  const timer = useRef();

  function handleInput(event) {
    if (event.target.id === 'emailInput') {
      setEmailInput(event.target.value);
    }
    if (event.target.id === 'passwordInput') {
      setPasswordInput(event.target.value);
    }
    if (event.target.id === 'confPasswordInput') {
      setConfPasswordInput(event.target.value);
    }
  }

  async function handleRegister() {
    try {
      if (await isInputDataValid()) {
        const user = await createUserWithEmailAndPassword(auth, emailInput, passwordInput);

        navigate('/auth/createNickname');
      }
    } catch (error) {
      if (error.message.includes('email-already-in-use')) {
        setValidationError((prev) => ({
          ...prev,
          email: 'This email is already registered!',
        }));
      }
    }
  }

  async function isInputDataValid() {
    const validInputs = [false, false, false];

    setValidationError({
      email: null,
      password: null,
      confPassword: null,
    });

    let errorCollector = {
      email: null,
      password: null,
      confPassword: null,
    };

    const correctEmailSyntax = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

    if (correctEmailSyntax.test(emailInput)) {
      validInputs[0] = true;
    } else {
      errorCollector = { ...errorCollector, email: 'Invalid email!' };
    }

    if (passwordInput.length > 7) {
      validInputs[1] = true;
      console.log(passwordInput.length);
    } else {
      errorCollector = {
        ...errorCollector,
        password: 'Password must contain at least 8 charachters!',
      };
    }

    if (confPasswordInput === passwordInput) {
      validInputs[2] = true;
    } else {
      errorCollector = {
        ...errorCollector,
        confPassword: "Pasword don't match",
      };
    }

    setValidationError(errorCollector);

    if (validInputs[0] && validInputs[1] & validInputs[2]) {
      return true;
    } else {
      return false;
    }
  }

  return (
    <menu className={classes.formContainer}>
      <h2 className={classes.method}>Register</h2>
      <div className={classes.inputContainer}>
        <label>Email</label>
        <input id="emailInput" onChange={handleInput} value={emailInput} type="email" />
        {validationError.email ? <p>{validationError.email}</p> : null}
      </div>
      <div className={classes.inputContainer}>
        <label>Password</label>
        <input id="passwordInput" onChange={handleInput} value={passwordInput} type="password" />
        {validationError.password ? <p>{validationError.password}</p> : null}
      </div>
      <div className={classes.inputContainer}>
        <label>Confirm password</label>
        <input id="confPasswordInput" onChange={handleInput} value={confPasswordInput} type="password" />
        {validationError.confPassword ? <p>{validationError.confPassword}</p> : null}
      </div>
      <div className={classes.otherRegisterBar}>
        <img src={GoogleLogo} alt="google" />
      </div>
      <button className="btn1" onClick={handleRegister}>
        Register
      </button>
    </menu>
  );
}
