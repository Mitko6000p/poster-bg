import classes from './AuthRegister.module.css';

import GoogleLogo from '../../assets/google-icon.png';
import { auth } from '../../firebase-config';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithEmailAndPassword } from 'firebase/auth';

export default function AuthLogin() {
  const navigate = useNavigate();

  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');

  const [validationError, setValidationError] = useState({ email: null, password: null });
  function logIn() {
    setValidationError({ email: null, password: null });
    if (emailInput.length > 0 && passwordInput.length > 0) {
      signInWithEmailAndPassword(auth, emailInput, passwordInput)
        .then(() => {
          navigate('/');
        })
        .catch((error) => {
          if (error.message.includes('invalid-credential')) {
            setValidationError((prev) => ({ ...prev, email: 'Invalid credentials!' }));
          }
        });
    } else {
      if (emailInput.length === 0) {
        setValidationError((prev) => ({ ...prev, email: 'This field is empty!' }));
      } else if (passwordInput.length === 0) {
        setValidationError((prev) => ({ ...prev, password: 'This field is empty!' }));
      }
    }
  }

  function handleInput(event) {
    if (event.target.id == 'emailInput') {
      setEmailInput(event.target.value);
    } else {
      setPasswordInput(event.target.value);
    }
  }

  useEffect(() => {
    if (auth.currentUser) {
      navigate('/');
    }
  }, []);
  return (
    <menu className={classes.formContainer}>
      <h2 className={classes.method}>Login</h2>
      <div style={{ marginTop: '35px' }}></div>
      <div className={classes.inputContainer}>
        <label>Email</label>
        <input id="emailInput" onChange={handleInput} value={emailInput} type="email" />
        {validationError.email ? <p>{validationError.email}</p> : null}
      </div>
      <div className={classes.inputContainer}>
        <label>Password</label>
        <input id="passwordInput" onChange={handleInput} value={passwordInput} type="password" />
        {validationError.password ? <p>{validationError.password}</p> : null}
      </div>
      <div className={classes.otherRegisterBar}>
        <img src={GoogleLogo} alt="google" />
      </div>
      <button onClick={logIn} className="btn1" style={{ width: '100px' }}>
        LogIn
      </button>
    </menu>
  );
}
