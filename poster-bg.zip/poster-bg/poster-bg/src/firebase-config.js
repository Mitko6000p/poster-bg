import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDI0kBLooWi7FFABeOLO6xDRvAYzEibiDE",
  authDomain: "poster-bg.firebaseapp.com",
  projectId: "poster-bg",
  storageBucket: "poster-bg.appspot.com",
  messagingSenderId: "644888066846",
  appId: "1:644888066846:web:1a44dc94fb695dd4fc670f",
  measurementId: "G-CFBJ7V3XPR",
  databaseURL:
    "https://poster-bg-default-rtdb.europe-west1.firebasedatabase.app",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
