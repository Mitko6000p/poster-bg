import { Route, Routes, Router, useLocation } from 'react-router-dom';
import Header from './components/Header/Header.jsx';
import PostsList from './components/PostsList/PostsList.jsx';
import Auth from './components/Auth/Auth.jsx';
import CreateNickname from './components/CreateNickname/CreateNickname.jsx';
import { useEffect, useState } from 'react';

function App() {
  return (
    <div>
      <Header />
      <Routes>
        <Route path="/" element={<PostsList />} />
        <Route path="/auth/:method" element={<Auth />} />
      </Routes>
    </div>
  );
}

export default App;
